class multiply_ready_driver extends uvm_driver #(multiply_ready_transaction);
    `uvm_component_utils(multiply_ready_driver)

    multiply_result_agent_config    agent_config;
    protected bit                   ready_active;

    function new(string name, uvm_component parent);
        super.new(name, parent);
    endfunction : new

    function void end_of_elaboration_phase(uvm_phase phase);
        super.end_of_elaboration_phase(phase);

        if (agent_config == null)
            `uvm_fatal("READY_DRIVER", "agent_config is null")
    endfunction : end_of_elaboration_phase

    task run_phase(uvm_phase phase);
        virtual multiply_if multiply_vif = agent_config.get_vif();

        forever begin
            wait (multiply_vif.resetn == 1'b1);

            fork
                drive_ready();
                reset_watch();
            join_any
            disable fork;

            if (ready_active) begin
                seq_item_port.item_done();
                ready_active = 1'b0;
            end

            multiply_vif.mul_res_ready_i <= 1'b0;
        end
    endtask : run_phase

    protected task drive_ready();
        multiply_ready_transaction ready;
        virtual multiply_if multiply_vif = agent_config.get_vif();

        forever begin
            seq_item_port.get_next_item(ready);
            ready_active = 1'b1;

            repeat (ready.ready_delay)
                @(multiply_vif.ready_cb);

            multiply_vif.ready_cb.mul_res_ready_i <= 1'b1;

            do begin
                @(multiply_vif.ready_cb);
            end while (!(multiply_vif.ready_cb.mul_res_valid_o == 1'b1 && multiply_vif.ready_cb.mul_res_ready_i == 1'b1));

            multiply_vif.ready_cb.mul_res_ready_i <= 1'b0;

            seq_item_port.item_done();
            ready_active = 1'b0;
        end
    endtask : drive_ready

    protected task reset_watch();
        virtual multiply_if multiply_vif = agent_config.get_vif();
        @(negedge multiply_vif.resetn);
    endtask : reset_watch

endclass : multiply_ready_driver